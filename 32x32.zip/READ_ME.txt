import numpy as np
import cv2

a=[]
with open("y_train_hash.txt")as ff:
	
	for line in ff:
		a.append(str(line))
X_train=[]
y_train=[]
counter=0

for ii in range(0,len(a)):
	if(ii in [2839,2853,3020,5136,5492,6061,6840]):
		continue
	X_train.append(cv2.imread("/home/rdey/project2_DSP/train_32x32/X_train"+str(ii)+".png",0))
	y_train.append((int)(a[ii])-1)
X_train=np.array(X_train)
y_train=np.array(y_train)
X_train=X_train.reshape(X_train.shape + (1,))

np.save("X_train",X_train)
np.save("y_train",y_train)



X_test=[]
for ii in range(0,2721):
	X_test.append(cv2.imread("/home/rdey/project2_DSP/test_32x32/X_test"+str(ii)+".png",0))
X_test=np.array(X_test)
X_test=X_test.reshape(X_test.shape+(1,))
np.save("X_test",X_test)


-------------------------- use the above to generate the X_train and X_test
As you  can see some images are corrupted in training set so I skipped them. 